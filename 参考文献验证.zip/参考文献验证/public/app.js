const inputText = document.getElementById("inputText");
const verifyButton = document.getElementById("verifyButton");
const clearButton = document.getElementById("clearButton");
const useExampleButton = document.getElementById("useExampleButton");
const resultList = document.getElementById("resultList");
const emptyState = document.getElementById("emptyState");
const requestStatus = document.getElementById("requestStatus");
const charCount = document.getElementById("charCount");
const progressBox = document.getElementById("progressBox");
const progressTitle = document.getElementById("progressTitle");
const elapsedText = document.getElementById("elapsedText");
const progressNote = document.getElementById("progressNote");
const progressBarFill = document.getElementById("progressBarFill");

const totalReferences = document.getElementById("totalReferences");
const realCount = document.getElementById("realCount");
const suspiciousCount = document.getElementById("suspiciousCount");
const fabricatedCount = document.getElementById("fabricatedCount");

const exampleText = `[1] Vaswani, A., Shazeer, N., Parmar, N., Uszkoreit, J., Jones, L., Gomez, A. N., Kaiser, L., & Polosukhin, I. (2017). Attention Is All You Need. Advances in Neural Information Processing Systems, 30.
[2] Piketty, T. (2014). Capital in the Twenty-First Century. Harvard University Press.
[3] Akqdp, Z. (2020). Trnsfrms of Plzvktic Manifolds in Bzfrxk Lattices. Nature Press.
[4] Devlin, J., Chang, M. W., Lee, K., & Toutanova, K. (2019). BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding. Proceedings of NAACL-HLT, 4171-4186.`;

let timerId = null;
let startedAt = 0;

function updateCharCount() {
  charCount.textContent = `${inputText.value.length} 字`;
}

function formatElapsed(seconds) {
  if (seconds < 60) {
    return `${seconds} 秒`;
  }

  const minutes = Math.floor(seconds / 60);
  const remainSeconds = seconds % 60;
  return `${minutes} 分 ${remainSeconds} 秒`;
}

function startElapsedTimer() {
  stopElapsedTimer();
  startedAt = Date.now();
  elapsedText.textContent = "已等待 0 秒";

  timerId = window.setInterval(() => {
    const seconds = Math.floor((Date.now() - startedAt) / 1000);
    elapsedText.textContent = `已等待 ${formatElapsed(seconds)}`;
  }, 1000);
}

function stopElapsedTimer() {
  if (timerId) {
    window.clearInterval(timerId);
    timerId = null;
  }
}

function setLoadingState(isLoading) {
  verifyButton.disabled = isLoading;
  clearButton.disabled = isLoading;
  useExampleButton.disabled = isLoading;
  requestStatus.className = `status-pill${isLoading ? " loading" : ""}`;
  requestStatus.textContent = isLoading ? "正在逐条核验" : "等待输入";
}

function setErrorState(message) {
  requestStatus.className = "status-pill error";
  requestStatus.textContent = message;
}

function setDoneState() {
  requestStatus.className = "status-pill done";
  requestStatus.textContent = "核验完成";
}

function statusLabel(status) {
  switch (status) {
    case "real":
      return "真实";
    case "suspicious":
      return "存疑";
    case "fabricated":
      return "虚构";
    default:
      return "存疑";
  }
}

function metadataMatchLabel(metadataMatch) {
  switch (metadataMatch) {
    case "high":
      return "匹配度高";
    case "partial":
      return "部分匹配";
    case "low":
      return "匹配度低";
    default:
      return "暂无法判断";
  }
}

function safeText(value) {
  if (value === null || value === undefined || value === "") {
    return "未提供";
  }

  if (Array.isArray(value)) {
    return value.length ? value.join("；") : "未提供";
  }

  return String(value);
}

function normalizeLine(line) {
  return line.replace(/\s+/g, " ").trim();
}

function isReferenceStart(line) {
  return /^(?:\[\d+\]\s+|\(\d+\)\s+|\d+[.)]\s+)/.test(line);
}

function isContinuationLine(line) {
  const normalized = normalizeLine(line);

  if (!normalized) {
    return false;
  }

  return (
    /^doi\s*:?\s*/i.test(normalized) ||
    /^10\.\d{4,9}\/\S+/i.test(normalized) ||
    /^(vol\.?|no\.?|pp\.?|pages?|art\.?\s*no\.?)\b/i.test(normalized) ||
    /^[,;:.)\]]/.test(normalized) ||
    /^(and|&)\b/i.test(normalized) ||
    /^[a-z]/.test(normalized)
  );
}

function currentNeedsContinuation(currentReference) {
  const normalized = normalizeLine(currentReference);

  if (!normalized) {
    return false;
  }

  return (
    /doi\s*:?\s*$/i.test(normalized) ||
    /(vol\.?|no\.?|pp\.?|pages?|art\.?\s*no\.?)\s*$/i.test(normalized) ||
    /[,;:]$/.test(normalized)
  );
}

function splitReferences(text) {
  const normalized = String(text || "").replace(/\r\n?/g, "\n").trim();

  if (!normalized) {
    return [];
  }

  const lines = normalized
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean);

  const references = [];
  let current = "";

  for (const line of lines) {
    if (isReferenceStart(line)) {
      if (current) {
        references.push(normalizeLine(current));
      }
      current = line;
      continue;
    }

    if (current && (currentNeedsContinuation(current) || isContinuationLine(line))) {
      current += ` ${line}`;
      continue;
    }

    if (current) {
      current += ` ${line}`;
    } else {
      current = line;
    }
  }

  if (current) {
    references.push(normalizeLine(current));
  }

  const strongReferences = references.filter((item) => item.length > 24);

  if (strongReferences.length >= 2) {
    return strongReferences;
  }

  const blockSplit = normalized
    .split(/\n\s*\n/)
    .map((item) => normalizeLine(item))
    .filter((item) => item.length > 24);

  if (blockSplit.length >= 2) {
    return blockSplit;
  }

  const mergedLines = [];
  let mergedCurrent = "";

  for (const line of lines) {
    if (!mergedCurrent) {
      mergedCurrent = line;
      continue;
    }

    if (isReferenceStart(line)) {
      mergedLines.push(normalizeLine(mergedCurrent));
      mergedCurrent = line;
      continue;
    }

    if (currentNeedsContinuation(mergedCurrent) || isContinuationLine(line)) {
      mergedCurrent += ` ${line}`;
      continue;
    }

    mergedLines.push(normalizeLine(mergedCurrent));
    mergedCurrent = line;
  }

  if (mergedCurrent) {
    mergedLines.push(normalizeLine(mergedCurrent));
  }

  const strongMergedLines = mergedLines.filter((line) => line.length > 24);

  if (strongMergedLines.length >= 2) {
    return strongMergedLines;
  }

  return [normalizeLine(normalized)];
}

function buildFailureResult(referenceText, errorMessage) {
  return {
    sourceText: referenceText,
    parsed: {
      title: "",
      authors: [],
      year: "",
      journal: "",
      volume: "",
      issue: "",
      pages: "",
      publisher: "",
      doi: ""
    },
    verification: {
      status: "suspicious",
      finalVerdict: "存疑",
      confidence: 0,
      paperExists: null,
      metadataMatch: "unknown",
      conclusion: "这一条参考文献暂时没能完成核验。",
      reason: errorMessage || "请求失败，请稍后重试。",
      suggestedCitation: ""
    }
  };
}

function createSummary() {
  return {
    totalReferences: 0,
    realCount: 0,
    suspiciousCount: 0,
    fabricatedCount: 0
  };
}

function updateSummaryWithResult(summary, result) {
  summary.totalReferences += 1;

  switch (result?.verification?.status) {
    case "real":
      summary.realCount += 1;
      break;
    case "suspicious":
      summary.suspiciousCount += 1;
      break;
    case "fabricated":
      summary.fabricatedCount += 1;
      break;
    default:
      break;
  }
}

function renderSummary(summary) {
  totalReferences.textContent = summary.totalReferences ?? 0;
  realCount.textContent = summary.realCount ?? 0;
  suspiciousCount.textContent = summary.suspiciousCount ?? 0;
  fabricatedCount.textContent = summary.fabricatedCount ?? 0;
}

function renderReferenceCard(item, index) {
  const parsed = item.parsed || {};
  const verification = item.verification || {};
  const finalVerdict =
    verification.finalVerdict || statusLabel(verification.status);

  return `
    <article class="result-card">
      <div class="result-card-header">
        <div>
          <h4>参考文献 ${index + 1}</h4>
          <div class="result-meta">
            <span>最终判别：<strong>${finalVerdict}</strong></span>
            <span>真实性置信度：<strong>${safeText(verification.confidence)}%</strong></span>
            <span>文献存在性：<strong>${
              verification.paperExists === null
                ? "暂无法判断"
                : verification.paperExists
                  ? "更像真实"
                  : "更像虚构"
            }</strong></span>
            <span>元数据匹配：<strong>${metadataMatchLabel(
              verification.metadataMatch
            )}</strong></span>
          </div>
        </div>
        <div class="badge ${verification.status || "suspicious"}">${finalVerdict}</div>
      </div>

      <div class="source-block">
        <strong>原始参考文献</strong>
        <div class="source-text">${safeText(item.sourceText)}</div>
      </div>

      <div class="parsed-block">
        <strong>识别出的信息</strong>
        <div class="parsed-grid">
          <div class="parsed-item"><span>标题</span><strong>${safeText(parsed.title)}</strong></div>
          <div class="parsed-item"><span>作者</span><strong>${safeText(parsed.authors)}</strong></div>
          <div class="parsed-item"><span>年份</span><strong>${safeText(parsed.year)}</strong></div>
          <div class="parsed-item"><span>期刊 / 会议 / 来源</span><strong>${safeText(parsed.journal)}</strong></div>
          <div class="parsed-item"><span>卷(期) / 页码</span><strong>${safeText(parsed.volume)}${parsed.issue ? ` (${safeText(parsed.issue)})` : ""} / ${safeText(parsed.pages)}</strong></div>
          <div class="parsed-item"><span>出版社 / DOI</span><strong>${safeText(parsed.publisher)} / ${safeText(parsed.doi)}</strong></div>
        </div>
      </div>

      <div class="advice-block">
        <strong>判别结论</strong>
        <div class="source-text">${safeText(verification.conclusion)}</div>
      </div>

      <div class="advice-block">
        <strong>核验说明</strong>
        <div class="source-text">${safeText(verification.reason)}</div>
      </div>

      <div class="correction-block">
        <strong>更规范的参考写法</strong>
        <div class="correction-box">${safeText(verification.suggestedCitation)}</div>
      </div>
    </article>
  `;
}

function appendResultCard(item, index) {
  resultList.insertAdjacentHTML("beforeend", renderReferenceCard(item, index));
}

function resetProgress() {
  progressBox.hidden = true;
  progressTitle.textContent = "准备开始";
  progressNote.textContent = "系统会逐条核验，不是卡住了，请稍候。";
  progressBarFill.style.width = "0%";
  elapsedText.textContent = "已等待 0 秒";
}

function updateProgress(currentIndex, total, currentReferenceText) {
  progressBox.hidden = false;

  if (currentIndex < total) {
    progressTitle.textContent = `正在核验第 ${currentIndex + 1} / ${total} 条`;
    progressNote.textContent = `系统正在逐条调用模型核验，不是卡住了。当前处理：${currentReferenceText.slice(
      0,
      60
    )}${currentReferenceText.length > 60 ? "..." : ""}`;
  } else {
    progressTitle.textContent = `已完成 ${total} / ${total} 条`;
    progressNote.textContent = "所有参考文献都已经核验完成。";
  }

  const completedPercent =
    total > 0 ? Math.round((currentIndex / total) * 100) : 0;
  progressBarFill.style.width = `${completedPercent}%`;
}

async function verifySingleReference(referenceText) {
  const response = await fetch("/api/verify-reference", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ referenceText })
  });

  const result = await response.json();

  if (!response.ok) {
    const detail = result.detail ? ` ${result.detail}` : "";
    throw new Error((result.error || "请求失败。") + detail);
  }

  return result;
}

async function handleVerify() {
  const text = inputText.value.trim();

  if (!text) {
    setErrorState("请先输入文本");
    emptyState.style.display = "block";
    emptyState.textContent = "请输入需要核验的参考文献内容。";
    resultList.innerHTML = "";
    return;
  }

  const references = splitReferences(text);

  if (!references.length) {
    setErrorState("没有识别到参考文献");
    emptyState.style.display = "block";
    emptyState.textContent = "请粘贴更完整的参考文献列表。";
    resultList.innerHTML = "";
    return;
  }

  setLoadingState(true);
  startElapsedTimer();
  renderSummary(createSummary());
  resultList.innerHTML = "";
  progressBox.hidden = false;
  emptyState.style.display = "block";
  emptyState.textContent = `已识别 ${references.length} 条参考文献，正在逐条核验，请稍候。`;

  const summary = createSummary();
  const results = [];

  try {
    for (let index = 0; index < references.length; index += 1) {
      const referenceText = references[index];
      updateProgress(index, references.length, referenceText);

      let result;

      try {
        result = await verifySingleReference(referenceText);
      } catch (error) {
        result = buildFailureResult(referenceText, error.message);
      }

      results.push(result);
      updateSummaryWithResult(summary, result);
      renderSummary(summary);

      if (emptyState.style.display !== "none") {
        emptyState.style.display = "none";
      }

      appendResultCard(result, index);
    }

    updateProgress(references.length, references.length, "");
    progressBarFill.style.width = "100%";
    setDoneState();
  } catch (error) {
    setErrorState("核验失败");
    emptyState.style.display = "block";
    emptyState.textContent = error.message || "发生未知错误。";
    resultList.innerHTML = "";
  } finally {
    stopElapsedTimer();
    verifyButton.disabled = false;
    clearButton.disabled = false;
    useExampleButton.disabled = false;
  }
}

inputText.addEventListener("input", updateCharCount);

verifyButton.addEventListener("click", handleVerify);

clearButton.addEventListener("click", () => {
  inputText.value = "";
  updateCharCount();
  renderSummary(createSummary());
  setLoadingState(false);
  resetProgress();
  stopElapsedTimer();
  emptyState.style.display = "block";
  emptyState.textContent =
    "粘贴参考文献后点击“开始逐条核验”，系统会边核验边把结果追加到下方。";
  resultList.innerHTML = "";
});

useExampleButton.addEventListener("click", () => {
  inputText.value = exampleText;
  updateCharCount();
});

resetProgress();
renderSummary(createSummary());
updateCharCount();
